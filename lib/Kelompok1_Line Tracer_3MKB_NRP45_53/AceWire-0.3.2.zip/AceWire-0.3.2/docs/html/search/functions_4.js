var searchData=
[
  ['twowireinterface_22',['TwoWireInterface',['../classace__wire_1_1TwoWireInterface.html#a8bd43efe7644927f55afd805c854976b',1,'ace_wire::TwoWireInterface']]]
];
