var searchData=
[
  ['begin_1',['begin',['../classace__wire_1_1SimpleWireFastInterface.html#aa9bd38babd4ff86d24fa1cc431bc550b',1,'ace_wire::SimpleWireFastInterface::begin()'],['../classace__wire_1_1SimpleWireInterface.html#af40440c29631bcac3e9d64818ac3f27c',1,'ace_wire::SimpleWireInterface::begin()'],['../classace__wire_1_1TwoWireInterface.html#a494ad44b23a2f5638ffd471fc01428c8',1,'ace_wire::TwoWireInterface::begin()']]],
  ['begintransmission_2',['beginTransmission',['../classace__wire_1_1SimpleWireFastInterface.html#a8cfd382e5ee0c42825ce19dfc1e388f4',1,'ace_wire::SimpleWireFastInterface::beginTransmission()'],['../classace__wire_1_1SimpleWireInterface.html#addf9e2d2a46b8f8ac156ca7c6a3f130c',1,'ace_wire::SimpleWireInterface::beginTransmission()'],['../classace__wire_1_1TwoWireInterface.html#aaf3ab9ab6c4dbf5e7b2741d1ab980788',1,'ace_wire::TwoWireInterface::beginTransmission()']]]
];
