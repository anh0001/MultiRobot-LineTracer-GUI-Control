var searchData=
[
  ['simplewirefastinterface_11',['SimpleWireFastInterface',['../classace__wire_1_1SimpleWireFastInterface.html',1,'ace_wire']]],
  ['simplewireinterface_12',['SimpleWireInterface',['../classace__wire_1_1SimpleWireInterface.html',1,'ace_wire']]]
];
