var searchData=
[
  ['twowireinterface_9',['TwoWireInterface',['../classace__wire_1_1TwoWireInterface.html',1,'ace_wire::TwoWireInterface&lt; T_WIRE &gt;'],['../classace__wire_1_1TwoWireInterface.html#a8bd43efe7644927f55afd805c854976b',1,'ace_wire::TwoWireInterface::TwoWireInterface()']]]
];
